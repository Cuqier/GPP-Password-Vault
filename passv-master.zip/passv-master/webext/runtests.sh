#!/bin/sh
set -e

cd "$(dirname "$(realpath "$0")")"

passed=0
failed=0

for f in test/*.js; do
	if [ -x "$f" ]; then
		printf "Running '%s'...    " "$f" >&2
		if node "$f" > /tmp/stdout; then
			passed="$((passed+1))"
		else
			failed="$((failed+1))"
			cat /tmp/stdout
		fi
	fi
done

printf '

\033[1mSummary:
    \033[32m%d\033[39m test(s) passed
    \033[31m%d\033[39m test(s) failed
\033[m' "$passed" "$failed" >&2

[ "$failed" -eq 0 ]

