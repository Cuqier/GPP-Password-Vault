#!/bin/sh
cd "$(dirname "$(realpath "$0")")"
exec web-ext run -u 'about:debugging#/runtime/this-firefox'
