#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    var key = await aesGenKey();
    var data = "MyRandomTestingDataFrame";
    var enc = await aesEncrypt(data, key);
    var enc2 = await aesEncrypt(data, key);
    assert(b64enc(enc) != b64enc(enc2));
});

