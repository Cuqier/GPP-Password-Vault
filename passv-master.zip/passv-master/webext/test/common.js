#!/usr/bin/env node

fs      = require("fs");
assert  = require("assert");
process = require("process");
crypto  = require("crypto").webcrypto;
fetch   = require("/usr/lib/node_modules/node-fetch");
argon2  = require("/usr/lib/node_modules/argon2-browser");

TESTENV = true;

window = global;

document = {
    getElementById: function() {
        return { addEventListener: function(){} };
    },
    getElementsByTagName: function() { return []; },
    querySelectorAll: function() { return []; }
};

browser = {
    storage: {
        local: {
            get: function(){},
            set: function(){}
        }
    }
};


(new vm.Script(fs.readFileSync("src/utils.js"))).runInThisContext();
(new vm.Script(fs.readFileSync("src/crypt.js"))).runInThisContext();
(new vm.Script(fs.readFileSync("src/dbase.js"))).runInThisContext();
(new vm.Script(fs.readFileSync("src/sync.js" ))).runInThisContext();
(new vm.Script(fs.readFileSync("src/pwgen.js"))).runInThisContext();

function runTest(func) {
    func().then(
        r => { console.error("\033[1;32mPassed\033[m");      process.exit(0); },
        e => { console.error("\033[1;31mFailed\033[m\n", e); process.exit(1); }
    );
}
