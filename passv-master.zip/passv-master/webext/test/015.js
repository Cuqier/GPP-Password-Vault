#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    var pass1 = genPasswd({
        length: 32,
        chars: [ 'lower', 'upper', 'special' ]
    });

    assert(pass1.match(/[A-Z]/));
});

