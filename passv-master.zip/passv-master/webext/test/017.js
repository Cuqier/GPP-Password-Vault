#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    var rls = parseRules("minlength: 100; required: lower,upper; required: [-]");
    var par = rules2params(rls);
    console.log(par);
    assert(par.length == 100);
});

