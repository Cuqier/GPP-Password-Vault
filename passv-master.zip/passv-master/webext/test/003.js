#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    var key = await aesGenKey();
    var data = "MyRandomTestingDataFrame";
    var enc = await aesEncrypt(data, key);

    var exkey = await aesExportKey(key);
    var exkey64 = b64enc(exkey);
    var exkey64dec = b64dec(exkey64);
    var key2 = await aesImportKey(exkey);

    var dec = await aesDecrypt(enc, key2);
    var sdec = arr2str(dec);
    assert(sdec == data);
});

