#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    await initDB();
    await initKeys("fajnynick@fajnyimejl.fjn", "fajowehaselko =)");
    await decryptDBKey();
    await decryptDB();

    await setLoginForDomain("example.com",  "TestUser",  "P@$$w0rd12");
    await setLoginForDomain("example2.com", "TestUser2", "P@$$w0rd12");
    await setLoginForDomain("kernel.org",   "TestUser",  "P@$$w0rd12");
    await setLoginForDomain("example.com",  "TestUser2", "P@$$w0rd12");

    var pass1 = getLoginsForDomain("kernel.org").TestUser.password;

    var key = cryptDB.keyForDB;
    var expdb = await exportDB(false);

    delete cryptDB;
    delete plainDB;

    await initDB();
    await initKeys("fajnynick@fajnyimejl.fjn", "fajowehaselko =)");
    cryptDB.keyForDB = key;
    await decryptDBKey();
    await decryptDB();

    await importDB(expdb, false);
    var pass2 = getLoginsForDomain("kernel.org").TestUser.password;

    assert(Object.keys(cryptDB.credentials).length == 4);
    assert(Object.keys(plainDB.credentials).length == 3);
    assert(pass1 == pass2);
});

