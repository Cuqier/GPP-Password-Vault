#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    var key = await aesGenKey();
    var data = "MyRandomTestingDataFrame";
    var enc = await aesEncrypt(data, key);
    var dec = await aesDecrypt(enc, key);
    var sdec = arr2str(dec);
    assert(sdec == data);
});

