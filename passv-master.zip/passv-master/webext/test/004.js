#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    var pass = "Password01234567";
    var salt = "Salt0123456789AB";
    var h1 = await arg2Hash(pass, salt);
    var h2 = await arg2Hash(pass, salt);
    assert(b64enc(h1) == b64enc(h2));
    assert(h1.length == 32);
});

