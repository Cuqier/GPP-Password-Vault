#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    var rls = parseRules("minlength: 10; required: lower,upper; required: [-]");
    var val = (p) => validatePasswd(p, rls);
    assert(!val("dupa"));
    assert(!val("dupaaaaaaaaaaaaaaaaaaaaa"));
    assert(val("dupaaaaAAAaa-aaaaaaaaaaaaa"));
});

