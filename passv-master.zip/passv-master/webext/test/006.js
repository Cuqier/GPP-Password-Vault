#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    await initDB();
    await initKeys("fajnynick@fajnyimejl.fjn", "fajowehaselko =)");
    await decryptDBKey();
    await decryptDB();
    assert(cryptDB.keyForDB);
});

