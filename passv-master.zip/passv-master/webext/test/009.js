#!/usr/bin/env node

vm = (global.require = require)("vm");
(new vm.Script(require("fs").readFileSync("test/common.js"))).runInThisContext();

runTest(async function() {
    await initDB();
    await initKeys("fajnynick@fajnyimejl.fjn", "fajowehaselko =)");
    await decryptDBKey();
    await decryptDB();

    await setLoginForDomain("example.com",  "TestUser",  "P@$$w0rd12");
    await setLoginForDomain("example2.com", "TestUser2", "P@$$w0rd12");
    await setLoginForDomain("kernel.org",   "TestUser",  "P@$$w0rd12");
    await setLoginForDomain("example.com",  "TestUser2", "P@$$w0rd12");

    delete plainDB;

    await initKeys("fajnynick@fajnyimejl.fjn", "fajowehaselko =)");
    await decryptDBKey();
    await decryptDB();

    assert(Object.keys(cryptDB.credentials).length == 4);
    assert(Object.keys(plainDB.credentials).length == 3);

});

