function arr2str(arr) {
    return String.fromCharCode.apply(null, arr);
}

function str2arr(str) {
    return new Uint8Array(str.split('').map(c => c.charCodeAt(0)));
}

function b64enc(arr) {
    return btoa(arr2str(arr));
}

function b64dec(b64) {
    return str2arr(atob(b64));
}

function arrcat(...ars) {
    var len = 0;
    for (var i = 0; i < ars.length; i++) {
        len += ars[i].length;
    }

    var ret = new Uint8Array(len);
    var pos = 0;
    for (var i = 0; i < ars.length; i++) {
        ret.set(ars[i], pos);
        pos += ars[i].length;
    }

    return ret;
}

function isEmpty(o) {
    return Object.keys(o).length == 0;
}

function deepCopy(o) {
    return JSON.parse(JSON.stringify(o));
}

async function getContentURL() {
    var url = await browser.tabs.query({currentWindow: true, active: true})
        .then((tabs) => {
            return tabs[0].url;
        });
    return url;
}

async function messageContent(cmd, params) {
    var mesg = deepCopy(params || {});
    mesg.cmd = cmd;
    return await browser.tabs.query({active: true, currentWindow: true})
        .then(tabs => browser.tabs.sendMessage(tabs[0].id, mesg));
}
