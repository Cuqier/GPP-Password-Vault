async function arg2Hash(pass, salt) {
    return argon2.hash({
        pass: pass,
        salt: salt,
        time: 1,
        mem: 1024,
        hashLen: 32,
        parallelism: 1,
        type: argon2.ArgonType.Argon2i,
    }).then(r => (/*console.log(r.hash+''),*/ r.hash))
      .catch(e => console.log(`argon2.hash: ${e.message} (${e.code})`));
}

function genRand(len) {
    return crypto.getRandomValues(new Uint8Array(len));
}

function genUUID() {
    var rand = genRand(32);
    var i = 0;
    return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/\d/g,
        c => (c ^ rand[i++] & 15 >> c / 4).toString(16)
    );
}

async function aesDeriveKey(bits) {
    return await crypto.subtle.importKey(
        "raw",
        bits,
        "AES-GCM",
        true,
        ["encrypt", "decrypt"]
    );
}

async function aesGenKey() {
    return await crypto.subtle.generateKey({
            name: "AES-GCM",
            length: 256
        },
        true,
        ["encrypt", "decrypt"]
    );
}

async function aesExportKey(key) {
    return new Uint8Array(
        await crypto.subtle.exportKey(
            "raw",
            key
        )
    );
}

async function aesImportKey(data) {
    return await crypto.subtle.importKey(
        "raw",
        data,
        "AES-GCM",
        true,
        ["encrypt", "decrypt"]
    );
}

async function aesEncrypt(data, key) {
    var iv = genRand(16)
    return arrcat(
        iv,
        new Uint8Array(
            await crypto.subtle.encrypt(
                {
                    name: "AES-GCM",
                    iv: iv
                },
                key,
                data
            )
        )
    );
}

async function aesDecrypt(crypt, key) {
    return new Uint8Array(
        await crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: crypt.subarray(0, 16)
            },
            key,
            crypt.subarray(16)
        )
    );
}

async function initKeys(email, mpass) {
    console.log("init keys start (begin of function)");
    var wa;
    // email & pass at least 8 chars
    //var email = "user@exampl.com";
    //var mpass = "password12";
    var domain = "passv.com";

    theEmail = email;
    theDomain = domain;

    if (wa) {
        masterHash = new Uint8Array([
            207,  12, 127,  67, 155,   3, 195,  26,
            192, 193, 158, 148,   3,   1,  60, 217,
             51, 126,  75,  43, 124,  87,  48,  11,
            132,  68, 114, 111, 209, 195,  46,  21
        ]);
    } else {
        masterHash = await arg2Hash(mpass, email);
    }

    console.log("init keys masterHash done (in function)");

    masterKey = await aesDeriveKey(masterHash);
    if (!wa) {
        loginHash = await arg2Hash(masterHash, domain + mpass);
        console.log("loginHash:", loginHash);
        //console.log("init keys loginHash done (in function)");
    }
    console.log("init keys done (end of function)");
}

async function decryptDBKey() {
    var cryptKey, plainKey;
    if ('keyForDB' in cryptDB) {
        console.log("init keys keyForDB in cryptDB start (in function)");
        try {
            cryptKey = b64dec(cryptDB.keyForDB);
            //console.log("init keys b64dec done (in function)");
            plainKey = await aesDecrypt(cryptKey, masterKey);
            //console.log("init keys aesDecrypt  done (in function)");
            keyForDB = await aesImportKey(plainKey);
            //console.log("init keys keyForDB in cryptDB done (in function)");
        } catch(e) {
            console.log("failed to decrypt vault key");
            if ('oldKeyForDB' in cryptDB) {
                console.log("old key present, attempting decrypt");
                cryptKey = b64dec(cryptDB.oldKeyForDB);
                plainKey = await aesDecrypt(cryptKey, masterKey);
                keyForDB = await aesImportKey(plainKey);
            }
        }
    } else {
        // TODO: shouldn't be needed on webext side since
        //       we can take care of keygen during registration

        console.log("init keys no keyForDB in cryptDB start (in function)");
        keyForDB = await aesGenKey();
        //console.log("init keys aesGenKey done (in function)");
        plainKey = await aesExportKey(keyForDB);
        //console.log("init keys aesExportKey (in function)");
        cryptKey = await aesEncrypt(plainKey, masterKey);
        //console.log("init keys aesEncrypt (in function)");
        cryptDB.keyForDB = b64enc(cryptKey);
        //console.log("init keys no keyForDB in cryptDB done (in function)");
    }
}

async function recryptDBKey(newPass) {
    if (typeof keyForDB == 'undefined') {
        console.log("recryptKey: keyForDB doesn't exist");
        return;
    }

    var newMasterHash = await arg2Hash(newPass, theEmail);
    console.log("newMasterHash =", newMasterHash);

    var newMasterKey = await aesDeriveKey(newMasterHash);
    console.log("newMasterKey =", newMasterKey);

    var plainKey = await aesExportKey(keyForDB);
    console.log("plainKey =", plainKey);

    var cryptKey = await aesEncrypt(plainKey, newMasterKey);
    console.log("cryptKey =", cryptKey);

    /* some basic sychronization is performed to accound for
     * connetction loss during recrypt:
     * 1. old key is backed up
     * 2. new key is set
     * 3. new key is transferred
     */

    cryptDB.oldKeyForDB = cryptDB.keyForDB;
    await saveDB();

    cryptDB.keyForDB = b64enc(cryptKey);
    console.log("cryptDB.keyForDB =", cryptDB.keyForDB);

    await syncSetKey(cryptDB.keyForDB);
    await saveDB();
}

