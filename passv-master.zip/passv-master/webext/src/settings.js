/*document.getElementById('action_box').addEventListener('change', function() {
  if (this.checked) {
    document.getElementById('action_type').innerHTML = "ENC"
    console.log("Enc is checked.");
  } else {
    document.getElementById('action_type').innerHTML = "PLAIN"
    console.log("Plain is checked.");
  }
});
*/


// export
document.getElementById('export').addEventListener('click', function() {
    var statuss = document.getElementById('action_box').checked;
    /*
    var text = 'sample text';
    var blob = new Blob([text], {type: 'text/plain;charset=utf-8'});
    var url = URL.createObjectURL(blob);

    browser.downloads.download({filename: "sumshite.txt", url, saveAs: true}, (id) => {
        handlers.push({id, url});
    });
    */

    let sending = browser.runtime.sendMessage({
        operation: "export",
        enc: statuss
    }).then(handleResponse, handleError);
});

function handleResponse(m) {
    console.log("import/export", m);

    switch (m.operation) {
        case "import":
            console.log(m);
            break;
        case "export":
            //message.res;
            console.log("export", m)
            var blob = new Blob([m.data], {type: 'text/plain;charset=utf-8'});
            var url = URL.createObjectURL(blob);
            browser.downloads.download({filename: "sumshite.txt", url, saveAs: true}, (id) => {
                handlers.push({id, url});
            });
            break;
    }
}

function handleError(m) {
    console.log(m);
}

// import
document.getElementById('import').addEventListener('click', function() {
    //var status = document.getElementById('action_box').checked;
    document.getElementById('ipmort').click();
});

document.getElementById('ipmort').addEventListener('change', function(e) {
    var statuss = document.getElementById('action_box').checked;
    //document.getElementById('ipmort').click();
    var file = e.target.files[0];
    if (!file) {
        return;
    }
    console.log(file);
    var reader = new FileReader();
    reader.onload = function(e) {
        //document.getElementById('contents').innerHTML = e.target.result;
        console.log(e.target.result);
        let sending = browser.runtime.sendMessage({
            operation: "import",
            enc: statuss,
            data: reader.result
        }).then(handleResponse, handleError);
    }
    reader.readAsText(file)
});

// change password
document.getElementById('ch_psswd').addEventListener('click', function() {
    console.log("ch_passwd");
    document.location.href = 'passwd.html';
});

// clipboard time
document.getElementById('clip_time').addEventListener('click', function() {
    var time = document.getElementById('clip_time_val').value;
    console.log("ttime:", time);
    let sending = browser.runtime.sendMessage({
            operation: "tset",
            ttime: time * 1000,
    }).then(handleResponse, handleError);
});

function handleTgetResponse(m) {
    console.log("Tget handler", m);
    document.getElementById('clip_time_val').value = m.ttime.ttime / 1000;
}

document.body.onload = function () {
    let sending = browser.runtime.sendMessage({
            operation: "tget",
    }).then(handleTgetResponse, handleError);
}
