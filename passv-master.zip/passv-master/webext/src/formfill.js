(function() {
function findLogin(uname, pass) {
    function setbrdr(e, c) {
        e.style.setProperty("border-width", "2px", "important");
        e.style.setProperty("border-color", c, "important");
    }

    var pwi, uni, fnd = false;
    for (var i = 0; i < document.forms.length; i++) {
        var els = document.forms[i].elements;
        for (var j = 0; j < els.length; j++) {
            if (els[j].hidden) {
                continue;
            }
            switch (els[j].type) {
            case "text": uni = els[j]; break;
            case "password": pwi = els[j]; break;
            }
        }
        if (pwi) {
            fnd = true;
            break;
        } else {
            pwi = uni = undefined;
        }
    }

    if (pwi) {
        setbrdr(pwi, "red");
        //pwi.value = pass;
        if (uni) {
            setbrdr(uni, "blue");
            //uni.value = uname;
            return [ uni, pwi ];
        }
    }
}

function formFillHandler(request, sender, sendResponse) {
    console.log("content request:", request.cmd);
    switch (request.cmd) {
    case "formfill": {
        //console.log('formfill');
        var lf = findLogin();
        if (lf) {
            lf[0].value = request.username;
            lf[1].value = request.password;
        }
        //sendResponse({response: "done!"});
        break;
    }
    case "pwrules": {
        var rules, lf = findLogin();
        if (lf) {
            rules = lf[1].getAttribute("passwordrules");
        }
        console.log("rules:", rules);
        sendResponse(rules);
        //sendResponse("minlength: 10; allowed: lower,upper;");
        break;
    }
    }
}

browser.runtime.onMessage.addListener(formFillHandler);
})();
