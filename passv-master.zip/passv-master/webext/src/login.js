/*document.getElementById('btn').addEventListener('click', x => {
    browser.browserAction.setIcon({path: "../res/vao.png"})
    browser.browserAction.setPopup({popup: "vault.html"})
    browser.browserAction.openPopup()
})*/
document.getElementById('frm').addEventListener('submit', async x => {
    x.preventDefault();


    var formData = new FormData(x.target);
    var email = formData.get("email");
    var mpass = formData.get("mpass");

    console.log(email, mpass);
    handleLogin(email, mpass);

    //browser.browserAction.setIcon({path: "../res/vao.png"});
    //browser.browserAction.setPopup({popup: "main.html"})
    //document.location.href = 'main.html';

})

function handleTgetResponse(message) {
    console.log("Login handler ttime Init" , message);
    browser.browserAction.setIcon({path: "../res/vao.png"});
    browser.browserAction.setPopup({popup: "main.html"})
    document.location.href = 'main.html';
}

function handleResponse(message) {
    console.log("Login handler Init" ,message.response);

    let s = browser.runtime.sendMessage({
        operation: "tget"
    });
    s.then(handleTgetResponse, handleError);

//    browser.browserAction.setIcon({path: "../res/vao.png"});
//    browser.browserAction.setPopup({popup: "main.html"})
//    document.location.href = 'main.html';
}

function handleError(message) {
    // handle bad login
    console.log("Login error handler" ,message);
}

function handleLogin(email, mpass) {
    let sending = browser.runtime.sendMessage({
        db: "init",
        email: email,
        mpass: mpass,
    });
    sending.then(handleResponse, handleError);
}
