//document.getElementById('btn').addEventListener('click', x => console.log('dupa'))
//document.addEventListener('click', x => console.log('dupa'))

/*function handleMessage(request, sender, sendResponse) {
  console.log("Message from the content script: " +
    request.domain);
  sendResponse({response: getLoginsForDomain(request.domain)});
}*/


function handleInitDB(request, sender, sendResponse) {

    async function init_sync() {
        var newdb = !await initDB();
        console.log("BG: ", request.email, request.mpass);
        await initKeys(request.email, request.mpass);

        try {
            await initSync();
        } catch(e) {
            console.log("initSync error:", e);
        }
        if (newdb) {
            console.log("fresh db has been created, need to pull key from server");
            var resp = await syncGetKey();
            cryptDB.keyForDB = resp.data;
            console.log("key from server:", cryptDB.keyForDB);
        }
        console.log("Init keys done!");
        await decryptDBKey();
        await decryptDB();
        try {
            await syncDoRefresh();
        } catch(e) {
            console.log("initSync error:", e);
        }
        //console.log("CDB:", cryptDB);
        //console.log("PDB:", plainDB);
        //console.log("InitDB: " + request.db);
    }

    if (request.db) {
        return init_sync().then(function() {
            return { response: 'init done!' };
        });
    }
}

function queryDB(request, sender, sendResponse) {
    if (request.domain) {
       console.log("QueryDB handler: " + request.domain);
       sendResponse({response: getLoginsForDomain(request.domain)});
    } else if (request.print === "db") {
        console.log("DB dump:");
        console.log(cryptDB);
        console.log(plainDB);
    }
}

function handleMgmnt(request, sender, sendResponse) {
    if (request.url) {
        console.log("Mgmnt handler: " + request.url, request.login);

        return new Promise( resolve => {
            setLoginForDomain(request.url, request.login, request.password);
            resolve({response: "Mgmnt done!"});
        });
    }
}

function handleDel(request, sender, sendResponse) {
    if (request.type === "delete") {
        return new Primise( resolve => {
            removeLoginForDomain(request.url, request.login);
        });
    }
}

function handleOpen(request, sender, sendResponse) {
    if (request.open) {
        browser.tabs.create({url: request.open});
    }
}

function dbOperations(request, sender, sendResponse) {
    /*
    return new Promise( resolve => {
        console.log("export");
        setTimeout( () => {
            resolve({m: 'test', operation: 'ops'});
        }, 1000);
    });*/
    switch (request.operation) {
        case "import":
            console.log("import");
            return importDB(request.data, request.enc).then( (res) => {
                return { operation: "import", data: 'done' };
            });
            break;
        case "export":
            console.log("export");
            return exportDB(request.enc).then( (res) => {
                console.log('res', res);
                return { operation: "export", data: res };
            });
            break;
    }
}

function clipTimer(request, sender, sendResponse) {
    switch (request.operation) {
        case "tset":
            console.log("tset", request.ttime);
            return browser.storage.local.set({ ttime: request.ttime }).then( (res) => {
                return { operation: "tset", ttime: request.ttime};
            });
            break;
        case "tget":
            console.log("tget");
            return browser.storage.local.get("ttime").then( (res) => {
                if (res.ttime) {
                    return { operation: "tget", ttime: res};
                }
                return browser.storage.local.set({ ttime: 10000 }).then( (res) => {
                    return { operation: "tset", ttime: 10000};
                });

            });
            break;
        case "tclean":
            console.log("tclean");
            return browser.storage.local.get("ttime").then( (res) => {
                setTimeout(() => {
                    navigator.clipboard.writeText("");
                    console.log("clipboard clean!");
                    return { operation: "tclean", status: "success"};
                }, res.ttime);
                return true;
            });
    }
}

browser.runtime.onMessage.addListener(queryDB);
browser.runtime.onMessage.addListener(handleInitDB);
browser.runtime.onMessage.addListener(handleMgmnt);
browser.runtime.onMessage.addListener(handleDel);
browser.runtime.onMessage.addListener(handleOpen);
browser.runtime.onMessage.addListener(dbOperations);
browser.runtime.onMessage.addListener(clipTimer);
