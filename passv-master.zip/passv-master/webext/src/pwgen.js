pwCharCls = {
    lower: "abcdefghijklmnopqrstuvwxyz",
    upper: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    digit: "0123456789",
    special: "-~!@#$%^&*_+=`|(){}[:;\"'<>,.? ]",
};

pwCharCls.ascii = pwCharCls.unicode = pwCharCls.lower + pwCharCls.upper + pwCharCls.digit + pwCharCls.special;



/*
 * Example usage:
 * var pass = genPasswd({
 *     length: 32,
 *     chars: [ 'lower', 'upper', 'digit', 'special' ]
 * });
 */

function genPasswd(reqs) {

    function cls4chr(c, a) {
        for (var i = 0; i < a.length; i++) {
            if (a[i].indexOf(c) >= 0) {
                return a[i];
            }
        }
    }

    function shuffle(s) {
        var a = s.split(""), n = a.length;
        var rbuf = crypto.getRandomValues(new Uint32Array(n));

        for(var i = n - 1; i > 0; i--) {
            var j = rbuf[i] % (i + 1);
            var tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
        }
        return a.join("");
    }

    /*var charCls = {
        lower: "abcdefghijklmnopqrstuvwxyz",
        upper: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        digit: "0123456789",
        symbl: "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
    }*/

    var arr = reqs.chars.map(x => pwCharCls[x]);

    var pw = [];
    for (var i = 0; i < reqs.length; i++) {
        pw[i] = shuffle(arr[i % arr.length])[0];
    }

    pw = shuffle(pw.join("")).split("");

    var rpt = 0, lst = "";
    for (var i = 0; i < pw.length; i++) {
        var c = pw[i];
        if (c == lst) {
            rpt++;
            if (rpt >= 1) {
                var cls = shuffle(cls4chr(c, arr));
                pw[i] = cls[cls[0] != c | 0];
            } else {
                continue;
            }
        }
        lst = c;
        rpt = 1;
    }

    console.log(pw.join(""), ", LEN =", pw.length);
    return pw.join("");
}

function parseRules(str) {
    console.log("==> parsing:", str);

    var re = /\s*(?<rule>[\w-]+)\s*:\s*(?<values>([\w-]+|\[[^\]]+\]\]?|\s*,\s*)+)\s*(;|$)/g;
    var ree = /(^|\s*,\s*)(?<value>[\w-]+|\[[^\]]+\]\]?)/g;
    var r, rr, ret = [];
    while ((r = re.exec(str)) !== null) {
        var values = [];
        while ((rr = ree.exec(r.groups.values)) !== null) {
            values.push(rr.groups.value);
        }
        ret.push({rule: r.groups.rule, values});
    }
    console.log(ret);
    return ret;
}

function rules2params(rules) {

    var params = { allowedspecial: "" };
    var length = 32;
    var allowed = {};

    for (var r of rules) {
        switch (r.rule) {
        case "minlength":       if (length < r.values[0]) length = r.values[0]; break;
        case "maxlength":       if (length > r.values[0]) length = r.values[0]; break;
        case "max-consecutive": params.maxconsec = r.values[0]; break;
        case "required":
        case "allowed": {
            for (var v of r.values) {
                switch (v) {
                    case "lower": allowed.lower = true; break;
                    case "upper": allowed.upper = true; break;
                    case "digit": allowed.digit = true; break;
                    case "special": allowed.special = true; break;
                    default: if (v[0] == '[') {
                        allowed.special = true;
                        params.allowedspecial += v.slice(1, -1);
                    } break;
                }
            }
            break;
        }
        }
    }

    if (!params.allowedspecial) {
        params.allowedspecial = pwCharCls.special;
    }

    if (!isEmpty(allowed)) {
        console.log(allowed);
        params.chars = [];
        for (var k in allowed) {
            if (allowed[k]) {
                params.chars.push(k);
            }
        }
    } else {
        params.chars = [ 'lower', 'upper', 'digit', 'special' ];
    }

    params.length = length;

    return params;
}

function validatePasswd(pass, rules) {

    function maxConsec(str) {
        var ch = '', run = 0, max = 0;
        for (var i = 0; i < str.length; i++) {
            if (str[i] == ch) {
                run++;
            } else {
                ch = str[i];
                if (run > max) max = run;
                run = 0;
            }
        }
        return max;
    }

    function mergeCls(clss) {
        var chars = '';
        for (var cls of clss) {
            if (cls[0] == '[') {
                chars += cls.slice(1, -1);
            } else {
                chars += pwCharCls[cls];
            }
        }
        return chars;
    }

    function cont(stra, strb) {
        for (var i = 0; i < stra.length; i++) {
            if (strb.indexOf(stra[i]) != -1) {
                return true;
            }
        }
        return false;
    }

    function ncont(stra, strb) {
        for (var i = 0; i < stra.length; i++) {
            if (strb.indexOf(stra[i]) == -1) {
                return true;
            }
        }
        return false;
    }

    var allowed = [];

    for (var r of rules) {
        switch (r.rule) {
        case "minlength":       if (pass.length < r.values[0]) return false; break;
        case "maxlength":       if (pass.length > r.values[0]) return false; break;
        case "max-consecutive": if (maxConsec(pass) > r.values[0]) return false; break;
        case "required":        if (!cont(pass, mergeCls(r.values))) return false;
        case "allowed":         allowed.push(...r.values); break;
        }
    }

    //console.log(allowed);

    if (allowed.length > 0) {
        allowed = mergeCls(allowed);
        if (ncont(pass, allowed)) {
            return false;
        }
    }

    return true;
}


document.getElementById('gen').addEventListener('click', function() {
    updatePasswd();
})

document.getElementById('plength').addEventListener('change', function() {
    document.getElementById('passwd_length').innerHTML = this.value;
})

document.getElementById('plength').addEventListener('input', function() {
    document.getElementById('passwd_length').innerHTML = this.value;
})

function updatePasswd() {


    var sets = Array.from(document.querySelectorAll("input[type='checkbox']:checked")).map( v => v.name)
    var len = document.getElementById('plength').value;

    document.getElementById('result').innerText = String(genPasswd({ length: len, chars: sets}))
}

if (typeof TESTENV == "undefined") {
    asdfasdf();
    updatePasswd();
}

var inputs = document.getElementsByTagName('input');
for (i = 0; i < inputs.length; ++i) {
    inputs[i].addEventListener('change', function() {
                updatePasswd();
            })
}

function asdfasdf() {
    var urlString = window.location.href;
    var paramString = urlString.split('?')[1];
    var queryString = new URLSearchParams(paramString);
    var intent = queryString.get("intent");
    console.log("intent:", intent);

    if (intent == "content") {
        var prevIntent = queryString.get("prev_intent");
        var url = queryString.get("url");
        var login = queryString.get("login");
        document.getElementById('copy').innerText = "Set";
        document.getElementById('copy').addEventListener('click', function() {
            var pass = document.getElementById('result').innerText;
            document.location.href = `mgmnt.html?intent=${encodeURIComponent(prevIntent)}&url=${encodeURIComponent(url)}&login=${encodeURIComponent(login)}&passw=${encodeURIComponent(pass)}`;
        });

        messageContent("pwrules").then(function(rules) {
            var rules = rules2params(parseRules(rules));
            console.log("rules:", rules);
            if ("length" in rules) {
                document.getElementById('passwd_length').innerHTML = rules.length;
            }
            if ("chars" in rules) {
                document.getElementById("lower").checked = false;
                document.getElementById("upper").checked = false;
                document.getElementById("digit").checked = false;
                document.getElementById("special").checked = false;
                for (var c of rules.chars) {
                    console.log("c:", c);
                    document.getElementById(c).checked = true;
                }
            }
            updatePasswd();
        });
    } else {
        document.getElementById('copy').addEventListener('click', function() {
            p = document.getElementById('result').innerText;
            console.log(p);
            navigator.clipboard.writeText(p);

            let sending = browser.runtime.sendMessage({
                operation: "tclean",
            }).then(handleTgetResponse, handleError);
        })
    }
}

function handleTgetResponse(m) {
    console.log(m);
}

function handleError(m) {
    console.log(m);
}
