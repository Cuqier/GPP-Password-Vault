
//cryptDB; // for server, localstorage
//plainDB; // for lookups

async function initDB() {
    var ret = true;
    console.log("1:");
    cryptDB = await browser.storage.local.get("cryptDB");
    console.log("2:", cryptDB);
    if (cryptDB && 'cryptDB' in cryptDB) {
        cryptDB = cryptDB.cryptDB;
    } else {
        console.log("creating new DB");
        cryptDB = {};
        ret = false;
        //cryptDB.keyForDB = "P8A7BJYL6Wn93pgFMlAFdcvF3fSK1QBjtQfL0G+zzq8sg30JhLYtJhQ9rpjVcvYbSjWMjycrQIjqBgPQpHPq2w==";
    }
    if (!cryptDB.credentials) {
        cryptDB.credentials = {};
    }
    if (!cryptDB.notes) {
        cryptDB.notes = {};
    }
    if (!cryptDB.removeds) {
        cryptDB.removeds = {};
    }
    console.log("3:", cryptDB);
    return ret;
}

async function decryptDB() {
    console.log("decrypt init")
    plainDB = {
        credentials: {},
        notes: {}
    };

    for (var id in cryptDB.credentials) {
        //console.log("processing: ", id);
        //console.log(keyForDB);
        var atime = cryptDB.credentials[id].atime;
        var {domain, user, password} = JSON.parse(arr2str(
            await aesDecrypt(b64dec(cryptDB.credentials[id].data), keyForDB)
        ));

        if (!(domain in plainDB.credentials)) {
            plainDB.credentials[domain] = {};
        }

        if (!(user in plainDB.credentials[domain])) {
            plainDB.credentials[domain][user] = {};
        }

        plainDB.credentials[domain][user].password = password;
        plainDB.credentials[domain][user].atime = atime;
        plainDB.credentials[domain][user].id = id;
    }
}

function saveDB() {
    return browser.storage.local.set({cryptDB});
}

function getAllEntryIds() {
    return new Set(Object.keys(cryptDB.credentials), Object.keys(cryptDB.notes));
}

// TODO: strip domain parameters before use
function getLoginsForDomain(domain) {
    return plainDB.credentials[domain] ?? {};
}

async function setLoginForDomain(domain, user, password) {
    if (!(domain in plainDB.credentials)) {
        plainDB.credentials[domain] = {};
    }

    var id;
    if (!(user in plainDB.credentials[domain])) {
        id = genUUID();
        plainDB.credentials[domain][user] = { id };
        cryptDB.credentials[id] = {};
    } else {
        id = plainDB.credentials[domain][user].id;
    }

    var atime = new Date().getTime();

    plainDB.credentials[domain][user].password = password;
    plainDB.credentials[domain][user].atime = atime;

    cryptDB.credentials[id].atime = atime;
    cryptDB.credentials[id].data = b64enc(await aesEncrypt(
        str2arr(JSON.stringify({ domain, user, password })),
        keyForDB
    ));

    saveDB();
    try { await syncDoRefresh(); } catch (e) { console.log(e); }
}

async function removeLoginForDomain(domain, user) {
    if (!(domain in plainDB.credentials && user in plainDB.credentials[domain])) {
        return;
    }

    var id = plainDB.credentials[domain][user].id;

    delete plainDB.credentials[domain][user];
    delete plainDB.credentials[domain][user];
    if (isEmpty(plainDB.credentials[domain])) {
        delete plainDB.credentials[domain];
    }

    delete cryptDB.credentials[id];

    cryptDB.removeds[id] = { atime: new Date().getTime() };

    saveDB();
    try { await syncDoRefresh(); } catch (e) { }
}

// Patches
function createDBDiff(since) {
    var diff = [];

    for (var type of ["credential", "note", "removed"]) {
        var data = cryptDB[type + "s"];
        for (var id in data) {
            var c = data[id];
            if (c.atime > since) {
                diff.push({
                    type,
                    id,
                    data: c.data,
                    atime: c.atime
                });
            }
        }
    }

    return diff;
}

async function mergeDBDiff(patch) {
    for (var e of patch) {
        var data = undefined;
        //console.log("e:",e)
        if (e.type != "removed") {
            data = cryptDB[e.type + "s"];
            if (!(e.id in data) || data[e.id].atime < e.atime) {
                console.log(`${e.id} (${e.type}): patch newer than local - overwriting`);
                data[e.id] = {
                    data: e.data,
                    atime: e.atime
                };
            } else {
                console.log(`${e.id} (${e.type}): local newer than patch - skipping`);
            }
        } else {
            for (var type of ["credentials", "notes"]) {
                if (e.id in cryptDB[type]) {
                    data = cryptDB[type];
                    break;
                }
            }
            if (!data) {
                console.log(`${e.id} (${e.type}): patch doesn't exist locally - skipping`);
            } else if (e.atime > data[e.id].atime) {
                console.log(`${e.id} (${e.type}): patch newer than local - deleting`);
                delete data[e.id];
                cryptDB.removeds[e.id] = { atime: e.atime };
            } else {
                console.log(`${e.id} (${e.type}): local newer than patch - not deleting`);
            }
        }
    }

    await decryptDB();
    saveDB();
}

// Import/Export

async function exportDB(encrypted) {
    data = deepCopy(cryptDB);

    delete data.removeds;

    if (encrypted) {
        return JSON.stringify(data);
    }

    delete data.keyForDB;
    for (var type of ["credentials", "notes"]) {
        var dt = data[type];
        for (var k in dt) {
            dt[k].data = arr2str(await aesDecrypt(b64dec(dt[k].data), keyForDB));
        }
    }

    return JSON.stringify(data);

}
async function importDB(data, encrypted) {

    function setSub(a, b) {
        a = new Set(deepCopy([...a]));
        for (i of b) {
            a.delete(i);
        }
        return a;
    }

    var data = deepCopy(JSON.parse(data));

    var prevKeys = getAllEntryIds();
    //console.log("prevKeys:", prevKeys);
    var prevRemoveds = new Set(Object.keys(cryptDB.removeds));
    //console.log("prevRemoveds:", prevRemoveds);

    if (!encrypted) {
        data.keyForDB = cryptDB.keyForDB;
        for (var type of ["credentials", "notes"]) {
            var dt = data[type];
            for (var k in dt) {
                //dt[k].data = arr2str(await aesDecrypt(b64dec(dt[k].data), keyForDB));
                dt[k].data = b64enc(await aesEncrypt(str2arr(dt[k].data), keyForDB));
            }
        }
    }

    var oldDB = cryptDB;
    cryptDB = data;

    var newKeys = getAllEntryIds();
    //console.log("newKeys:", newKeys);
    var together = new Set([...prevKeys, ...prevRemoveds]);
    //console.log("together:", together);
    var newRemoveds = setSub(together, newKeys);
    //console.log("newRemoveds:", newRemoveds);
    cryptDB.removeds = {};
    for (var i of [...newRemoveds]) {
        console.log(i);
        cryptDB.removeds[i] = { atime: (i in oldDB.removeds) ? oldDB.removeds[i].atime : new Date().getTime() };
    }
    await decryptDB();
    saveDB();
    try { await syncDoRefresh(); } catch (e) { }
}

