document.body.onload = function() {
    let urlString = window.location.href;
    let paramString = urlString.split('?')[1];
    let queryString = new URLSearchParams(paramString);

    var intent = queryString.get("intent");

    var url = queryString.get('url');
    if (url && url != "null") {
        document.getElementById('url').value = url;
    }

    var passw = queryString.get('passw');
    if (passw && passw != "null") {
        document.getElementById('passw').value = passw;
    }

    var login = queryString.get('login');
    if (login && login != "null") {
        document.getElementById('login').value = login;
    }

    var gb = document.getElementById("genpass");
    gb.addEventListener("click", function() {
        document.location.href = `gen_passwd.html?intent=content&prev_intent=${encodeURIComponent(intent)}&url=${encodeURIComponent(url)}&login=${encodeURIComponent(login)}`;
    }, false);

    if (intent == "modify") {
        /*for (let pair of queryString.entries()) {
            console.log("Key is: " + pair[0]);
            console.log("Value is: " + pair[1]);
            document.getElementById(pair[0]).value = pair[1];
        }*/

        document.getElementById("btn").value = "Change";
        var b = document.getElementById("del_but");

        b.removeAttribute("hidden");
        b.addEventListener("click", function() {
            let sending = browser.runtime.sendMessage({
                type: "delete",
                url: url,
                login: login,
            });
            sending.then(handleResponse, handleError);
            document.location.href = 'main.html';
        }, false);
    } else if (intent == "create") {
        console.log("new passowrd");
        getContentURL().then(url => document.getElementById('url').value = url);
        //messageContent("pwrules").then(rules => document.getElementById('login').value = rules);
    }
};

document.getElementById('frm').addEventListener('submit', async x => {
    var formData = new FormData(x.target);
    url = formData.get("url");
    login = formData.get("login");
    passw = formData.get("passw");

    // send message

    let sending = browser.runtime.sendMessage({
        url: url,
        login: login,
        password: passw
    });

    sending.then(handleResponse, handleError);
    document.location.href = 'main.html';
});

function handleError(error) {
  console.log(`Error: ${error}`);
}

function handleResponse(message) {
  console.log(`Response Mgmnt: ${message.response}`);
}
