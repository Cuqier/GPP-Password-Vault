syncDomain = "127.0.0.1:8000"; // theDomain
// syncAuthToken - server token
// syncAuthTimestamp

//fetch = require("/usr/lib/node_modules/node-fetch");

async function initSync() {
    var encLoginHash = b64enc(loginHash);
    console.log("initSync: login:", theEmail, "password:", encodeURIComponent(loginHash));
    var resp = await fetch(`http://${syncDomain}/token/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json;charset=utf-8' },
        body: JSON.stringify({
            username: theEmail,
            password: encLoginHash
        })
    });
    var data = await resp.json();
    syncAuthToken = data.access;
    console.log("syncAuthToken:", syncAuthToken);
}

async function syncRequest(endp, params, meth = "GET", useJSON = false) {
    /*var fetchData = {
        method: meth,
        headers: {
            "Content-Type': "application/json;charset=utf-8",
            "Authorization": `Bearer ${syncAuthToken}`
        },
        body: JSON.stringify(params)
    };*/
    // JSON API my ass
    var fetchData;
    switch(meth) {
    case "GET":
    case "HEAD": {
        fetchData = {
            method: meth,
            headers: {
                "Authorization": `Bearer ${syncAuthToken}`
            },
        };
        break;
    }

    default: {
        if (useJSON) {
        console.log("JSON body:", JSON.stringify(params));
        fetchData = {
            method: meth,
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": `Bearer ${syncAuthToken}`
            },
            body: JSON.stringify(params)
        };
        } else {
        fetchData = {
            method: meth,
            headers: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                "Authorization": `Bearer ${syncAuthToken}`
            },
            body: new URLSearchParams(params)
        };
        }
        break;
    }
    }

    var resp = await fetch(`http://${syncDomain}${endp}`, fetchData);
    var text = await resp.text();
    console.log("resp:", text);
    if (!text) {
        return null;
    }
    try {
        return JSON.parse(text);
    } catch(e) {
        // sometimes the server doesn't give us a valid JSON array
        // like "[ {...}, {...} ]"  and instead produces "{...} {...}"
        // this is an ugly attempt to work around that crap
        var ctext = text.replace(/}{(?=([^"]*"[^"]*")*[^"]*$)/g, '},{'); // also, vim sucks: "
        return JSON.parse('[' + ctext + ']');
    }
}

async function syncGetVault(since) {
    var srvdat;
    //if (typeof since == "undefined") {
        srvdat = await syncRequest("/vault/");
    //} else {
    //    srvdat = await syncRequest(`/vault/?since=${since}`);
    //}
    console.log("server data:", srvdat);
    if (!srvdat) {
        return [];
    }
    /*if (!srvdat.length) {
        srvdat = [ srvdat ];
    }*/
    // patch dataframes returned from server use "uid" instead
    // of "id", and stuff like 10 other fields in each entry
    var data = [];
    for (var ent of srvdat) {
        if (typeof since != "undefined") {
            if (ent.atime < since) {
                continue;
            }
        }

        try {
        data.push({
            id: ent.uid,
            type: ent.type,
            atime: ent.atime,
            data: ent.data,
        });
        } catch (e) { console.log(e); }
    }
    return data;
}

async function syncPutVault(data) {
    return await syncRequest("/vault/", data, 'PUT', true);
}

async function syncGetKey() {
    return await syncRequest("/vault/key/");
}

async function syncSetKey(newKey) {
    return await syncRequest("/vault/key/", { key: newKey }, 'POST');
}

async function syncGetShare() {
    return await syncRequest("");

}

async function syncMakeShare() {
    return await syncRequest("");

}

async function syncDelShare() {
    return await syncRequest("");

}

async function syncDoRefresh() {
    console.log("sync refresh started");
    var syncLastRefresh = await browser.storage.local.get("syncLastRefresh");
    syncLastRefresh = (syncLastRefresh && "syncLastRefresh" in syncLastRefresh)
        ? syncLastRefresh.syncLastRefresh : 0;

    console.log("syncLastRefresh:", syncLastRefresh);
    var serverStuff = await syncGetVault(syncLastRefresh);
    console.log("serverStuff:", serverStuff);
    if (serverStuff.length > 0) {
        await mergeDBDiff(serverStuff);
    }
    var clientStuff = createDBDiff(syncLastRefresh);
    console.log("clientStuff:", clientStuff);
    if (clientStuff.length > 0) {
        await syncPutVault(clientStuff);
    }

    await browser.storage.local.set({ syncLastRefresh: new Date().getTime() });
    console.log("sync refresh finished");
}

