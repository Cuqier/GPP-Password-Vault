/*document.getElementById('btn').addEventListener('click', x => {
    browser.browserAction.setIcon({path: "../res/vao.png"})
    browser.browserAction.setPopup({popup: "vault.html"})
    browser.browserAction.openPopup()
})*/
var elements; //current loaded vault elements

document.getElementById('frm').addEventListener('submit', async x => {
    browser.browserAction.setIcon({path: "../res/vac.png"});
    browser.browserAction.setPopup({popup: "login.html"});
    //x.preventDefault();
})
document.getElementById('btn').addEventListener('click', async x => {
    browser.browserAction.setIcon({path: "../res/vac.png"});
    browser.browserAction.setPopup({popup: "login.html"});
    document.location.href = 'login.html';
})

document.getElementById('mgmnt').addEventListener('click', async x => {
    document.location.href = 'mgmnt.html?intent=create';
})

document.getElementById('printDB').addEventListener('click', async x => {
    let sending = browser.runtime.sendMessage({
        print: "db"
    })
})

document.getElementById('settings').addEventListener('click', async x => {
    console.log("enter settings");
    //document.location.href = 'settings.html';
    let sending = browser.runtime.sendMessage({
        open: "htm/settings.html"
    })

})

document.getElementById('gen_passwd').addEventListener('click', async x => {
    console.log("enter gen_passwd");
    document.location.href = 'gen_passwd.html?intent=misc';

})


//    sending.then(handleResponse, handleError);

function handleResponse(message) {
  console.log("qury handler", message.response);
  //document.getElementById('test').innerHTML = `${message.response}`;

    document.getElementById('list').innerHTML = '';
    for (let [key, value] of Object.entries(message.response)) {
        console.log(key, value);
        elements = message.response;

        let li = document.createElement("li");
        li.setAttribute("class", "elem");

        let d1 = document.createElement("div");
        d1.setAttribute("class", "ename");
        console.log(value.password)
        d1.addEventListener("click", function() { fillForm(key, value.password); }, false);

        let name_ico = document.createElement("img");
        name_ico.setAttribute("class", "ico");
        name_ico.setAttribute("src", "../res/ie_ico.png");

        let name = document.createElement("p");
        name.setAttribute("class", "name");
        name.innerHTML = key;

        d1.appendChild(name_ico);
        d1.appendChild(name);

        let d2 = document.createElement("div");
        d2.setAttribute("class", "icons");

        let edit_ico = document.createElement("img");
        edit_ico.setAttribute("class", "ico");
        edit_ico.setAttribute("src", "../res/edit_ico.png");
        edit_ico.addEventListener("click", function() { editCbHandler(key, value.password); }, false);

        let user_ico = document.createElement("img");
        user_ico.setAttribute("class", "ico");
        user_ico.setAttribute("src", "../res/user_ico.png");
        user_ico.addEventListener("click", function() { unameCbHandler(key); }, false);

        let pass_ico = document.createElement("img");
        pass_ico.setAttribute("class", "ico");
        pass_ico.setAttribute("src", "../res/pass_ico.png");
        pass_ico.addEventListener("click", function() { passCbHandler(key); }, false);

        d2.appendChild(edit_ico);
        d2.appendChild(user_ico);
        d2.appendChild(pass_ico);

        li.appendChild(d1);
        li.appendChild(d2);

        document.getElementById('list').appendChild(li);
    }

    // console.log(elements['testuser']);
}

async function editCbHandler(login, pass) {
    console.log("edit: "+ name);
    url = await browser.tabs.query({currentWindow: true, active: true})
    .then((tabs) => {
      return tabs[0].url;
  });

    document.location.href = `mgmnt.html?intent=modify&url=${url}&login=${login}&passw=${pass}`;
}

function unameCbHandler(name) {
    console.log("uname: "+ name);
    navigator.clipboard.writeText(name);
    let sending = browser.runtime.sendMessage({
            operation: "tclean",
    }).then(handleTgetResponse, handleError);
}

function passCbHandler(name) {
    console.log("pass: "+ name);
    navigator.clipboard.writeText(elements[name].password);
    let sending = browser.runtime.sendMessage({
            operation: "tclean",
    }).then(handleTgetResponse, handleError);
}

function handleTgetResponse(m) {
    console.log(m);
}

function handleError(error) {
  console.log(`Error: ${error}`);
}

async function loadElementsFromDB(e) {
  /*url = await browser.tabs.query({currentWindow: true, active: true})
    .then((tabs) => {
      return tabs[0].url;
  });*/
  var url = await getContentURL();

  let sending = browser.runtime.sendMessage({
    domain: url
  });

  console.log(url);
  sending.then(handleResponse, handleError);
}

function fillForm(username, password) {
    messageContent("formfill", { username, password });
}

window.addEventListener("load", loadElementsFromDB);


