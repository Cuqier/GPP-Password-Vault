document.getElementById('btn').addEventListener('click', function() {
    //logout

    document.location.href = 'login.html';
})
