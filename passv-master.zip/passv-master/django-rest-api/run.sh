#!/bin/sh

cd "$(dirname "$(realpath "$0")")"

basedir="$(pwd)"
addr='localhost:8000'

cp api_server/api_server/settings.py api_server/api_server/settings.py.old
cp test/settings.py.testenv api_server/api_server/settings.py

python3 -mvenv --system-site-packages server-venv
. server-venv/bin/activate
pip3 install -r requirements.txt

cleanup() {
	echo "cleaning up"
	cd "$basedir"
	mv api_server/api_server/settings.py.old api_server/api_server/settings.py
	rm -fr server-venv
}
trap 'cleanup' EXIT INT

cd api_server
rm -f db.sqlite3
python3 manage.py makemigrations vault
python3 manage.py makemigrations user
python3 manage.py migrate
python3 manage.py runserver

