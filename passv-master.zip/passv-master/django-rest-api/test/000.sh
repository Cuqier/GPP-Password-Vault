#!/bin/sh

(
set -e
addr='localhost:8000'
user='test@example.com'
pass='RRKARsxh%2B4Y2grBXA2wfoBT4VimuiiCvVW0k5ZkRFUA%3D'
#pass='RRKARsxh+4Y2grBXA2wfoBT4VimuiiCvVW0k5ZkRFUA='
key='%2FAYtqVJ%2BfXSZfASGCS%2BNkeKg3M41fiQfJk%2FG3PmK7IbbZpLJuEmHva7htASbRsJjxbDiXHVeFbLMd5sLEbT7%2Fw%3D%3D'

auth="$(curl -XPOST -d"username=$user" -d"password=$pass" "$addr/user/" \
        | tee /dev/stderr \
		| jq -r .activation.athorization_url)"
curl "$auth"

token="$(curl -XPOST -d"username=$user" -d"password=$pass" "$addr/token/" \
         | tee /dev/stderr \
         | jq -r .access)"

curl -XPOST -d"key=${key}" -H "Authorization: Bearer ${token}" "$addr/vault/key/"

) 2>&1

rc="$?"

if [ "$rc" -eq 0 ]; then
	printf '\033[1;32mPassed\033[m\n' >&2
else
	printf '\033[1;31mFailed\033[m\n' >&2
fi

exit "$rc"
