#!/usr/bin/env python3

import os, sys, requests

ADDR = 'http://localhost:8000'
USER = 'test@example.com'
PASS = 'RRKARsxh+4Y2grBXA2wfoBT4VimuiiCvVW0k5ZkRFUA='

def main():
    r = requests.post(f'{ADDR}/token/', json={ 'username': USER, 'password': PASS })
    #print(r.json())
    token = r.json()['access']
    print(token)
    assert token

    r = requests.get(f'{ADDR}/vault/', headers={ 'Authorization': f'Bearer {token}' })
    print(r.text)
    assert not r.json()


if __name__ == '__main__':
    try:
        main()
        print('\033[1;32mPassed\033[m', file=sys.stderr)
    except BaseException as e:
        print('\033[1;31mFailed\033[m', file=sys.stderr)
        print(e, file=sys.stderr)
        exit(1)

