#!/usr/bin/env python3

import os, sys, requests

ADDR = 'http://localhost:8000'
USER = 'test@example.com'
PASS = 'RRKARsxh+4Y2grBXA2wfoBT4VimuiiCvVW0k5ZkRFUA='

def main():
    r = requests.post(f'{ADDR}/token/', json={ 'username': USER, 'password': PASS })
    #print(r.json())
    token = r.json()['access']
    print(token)
    assert token

    patch_data = [
        {
            'type': 'credential',
            'id': 'e7c859bd-d067-73d5-b592-9d6ae4dcc933',
            'data': 'zja3fI3sqd1l5ffyA2jInQFZv+0d4yZnI9GmW53fWOuw6UNyX/SvD3+cq4QD6iFbPexWWfdAvFUqrw+QChO6pjKo+eaSzXNEfzFNHNJcfoCwWEChj5s5rAoP7/0DdGp7XcWYFQ==',
            'atime': 1652350600981
        },
        {
            'type': 'credential',
            'id': '16f90bac-622d-5057-8a6c-266cd473da04',
            'data': 'WzA67T9fm8LPJpuOGa6JaeHvIfHsOxf2g5wRCwJPPC/83rJEf4jIeG6A5QB7gG1NSkEx0hWCil+2WTX3E8PnZbUizJ8FhTTRNTPhoh4O4hoMXzxeVlOvsbPlnYVYF0XAlXmV',
            'atime': 1652350600981
        },
        {
            'type': 'removed',
            'id': '6477a8fc-4763-7a2c-8075-a38a8b4c1e83',
            'data': None,
            'atime': 1652350600982
        },
        {
            'type': 'removed',
            'id': '34dcb0e7-2b94-23f3-a2a4-4a73020bde4f',
            'data': None,
            'atime': 1652350600982
        }
    ]

    r = requests.put(f'{ADDR}/vault/', headers={ 'Authorization': f'Bearer {token}' }, json=patch_data)
    r = requests.get(f'{ADDR}/vault/', headers={ 'Authorization': f'Bearer {token}' })
    assert len(r.json()) == 2


if __name__ == '__main__':
    try:
        main()
        print('\033[1;32mPassed\033[m', file=sys.stderr)
    except BaseException as e:
        print('\033[1;31mFailed\033[m', file=sys.stderr)
        print(e, file=sys.stderr)
        exit(1)

