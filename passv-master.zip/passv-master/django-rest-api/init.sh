#!/bin/sh

python manage.py makemigrations vault
python manage.py makemigrations user
python manage.py migrate 

#python manage.py runserver 0.0.0.0:8000
gunicorn --certfile=/etc/certs/localhost.crt --keyfile=/etc/certs/localhost.key api_server.wsgi:application --bind 0.0.0.0:443
