#!/usr/bin/bash

DOMAIN="localhost:8000"

### USER ###
create_user() {
    EMAIL="$1"
    PASSWORD="$2"
    curl -XPOST -d"username=${EMAIL}" -d"password=${PASSWORD}" "${DOMAIN}/user/"
}

activate_user() {
    ACTIVATE_URL="$1"
    curl "${ACTIVATE_URL}"
}

change_user_password() {
    NEW_PASSWORD="$1"
    curl -XPATCH -d"password=${NEW_PASSWORD}" -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/user/"
}

delete_user() {
    NEW_PASSWORD="$1"
    curl -XDELETE -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/user/"
}

### TOKEN ###
get_user_token() {
    EMAIL="$1"
    PASSWORD="$2"
    curl -XPOST -d"username=${EMAIL}" -d"password=${PASSWORD}" "${DOMAIN}/token/"
}

refresh_user_token() {
    REFRESH="$1"
    curl -XPOST -d"refresh=${REFRESH}" -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/token/refresh/"
}

### VAULT ###
get_user_vault() {
    NEW_PASSWORD="$1"
    curl -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/vault/"
}

get_user_vault_uid() {
    ID="$1"
    curl -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/vault/?uid=${ID}"
}

get_user_vault_since() {
    SINCE="$1"
    curl -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/vault/?since=${SINCE}"
}

put_user_vault() {
    # file name with json to add e.g. test.json from this folder
    FN="$1"
    curl -XPUT -H "Authorization: Bearer ${ACCESS_TOKEN}" --data "@${FN}" "${DOMAIN}/vault/"
}

### VAULT KEY ###
get_vault_key() {
    curl -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/vault/key/"
}

# create or update key
change_vault_key() {
    KEY="$1"
    curl -XPOST -d"key=${KEY}" -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/vault/key/"
}

### Note sharing ###

get_share() {
    UUID="$1"
    curl "${DOMAIN}/vault/share/${UUID}/"
}

create_share() {
    UUID="$1"
    SHARE_DATA="$2"
    curl -XPOST -d"share_data=${SHARE_DATA}" -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/vault/share/${UUID}/"
}

remove_share() {
    UUID="$1"
    curl -XDELETE -H "Authorization: Bearer ${ACCESS_TOKEN}" "${DOMAIN}/vault/share/${UUID}/"
}

$@
