from django.db import models
import json
import uuid

class Vault(models.Model):
    
    username = models.TextField()
    type = models.TextField()
    uid = models.UUIDField(
            primary_key = False,
            default = uuid.uuid4,
            editable = False)
    data = models.TextField()
    share_data = models.TextField(null=True)
    atime = models.PositiveBigIntegerField()

    def __eq__(self, other):
        this = [ self.type, uuid.UUID(self.uid), self.data, self.atime ]
        that = [ other.type, other.uid, other.data, other.atime ]

        if this == that:
                return True
        return False

    def __str__(self):
        return str({ "username": self.username,
                "type": self.type,
                "uid": str(self.uid),
                "data": self.data,
                "share_data": self.share_data,
                "atime": self.atime
                })

    def __repr__(self):
        return json.dumps({ "username": self.username,
                "type": self.type,
                "uid": str(self.uid),
                "data": self.data,
                "share_data": self.share_data,
                "atime": self.atime
                })

    def toJson(self):
        return json.dumps({ "username": self.username,
                "type": self.type,
                "uid": str(self.uid),
                "share_data": self.share_data,
                "atime": self.atime
                })

class VaultKey(models.Model):
    username = models.TextField(primary_key = True)
    data = models.TextField()

    def toJson(self):
        return json.dumps({ "username": self.username,
                "data": self.data,
                })

