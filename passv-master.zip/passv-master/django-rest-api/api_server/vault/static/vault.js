var x = "dupa"
