from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from django.views.decorators.csrf import csrf_exempt
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate
from rest_framework_simplejwt.token_blacklist.models import BlacklistedToken, OutstandingToken

from django.contrib.auth.models import User
from django.http import HttpResponse
import json
import jwt
from rest_framework_simplejwt.views import TokenObtainPairView
from user.serializers import MyTokenObtainPairSerializer
from rest_framework.authentication import get_authorization_header
from api_server.settings import SECRET_KEY
from vault.models import Vault, VaultKey

from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from user.activate_tokens import account_activation_token

from django.core import serializers
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import render


@permission_classes((AllowAny,))
class VaultShareHandler(APIView):

    def get_permissions(self):
        permission_classes = [IsAuthenticated]
        if self.request.method == "GET":
            permission_classes = [AllowAny]
        return [permission() for permission in permission_classes]

    @csrf_exempt
    def get(self, request, uuid):
        try:
            share = Vault.objects.get(uid=uuid)

            if not share.share_data:
                return HttpResponse(json.dumps({"message": "no data found!"}), content_type="application/json", status=404)
        
        except ObjectDoesNotExist:
            return HttpResponse(json.dumps({"message": "no data found!"}), content_type="application/json", status=404)
       
        return render(request, "share.html", {"data": share.toJson()})

    @csrf_exempt
    def post(self, request, uuid):
        share_data = request.POST.get("share_data")
        username = self.parse_token(request, "username")
        
        try:
            share = Vault.objects.get(uid=uuid, username=username)
        except ObjectDoesNotExist:
            return HttpResponse(json.dumps({"message": "no data found!"}), content_type="application/json", status=404)
       
        share.share_data = share_data
        share.save()

        return HttpResponse(json.dumps({"message": "Note successfully shared"}), content_type="application/json", status=200)

    @csrf_exempt
    def delete(self, request, uuid):
        username = self.parse_token(request, "username")
        
        try:
            share = Vault.objects.get(uid=uuid, username=username)
        except ObjectDoesNotExist:
            return HttpResponse(json.dumps({"message": "no data found!"}), content_type="application/json", status=404)
       
        share.share_data = None
        share.save()

        return HttpResponse(json.dumps({"message": "Note successfully removed from shared"}), content_type="application/json", status=200)

    def parse_token(self, request, field):
        token = str(get_authorization_header(request))[1:-1].split(" ")[1]
        token_data = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return token_data[field]

    
@permission_classes((IsAuthenticated,))
class VaultKeyHandler(APIView):
    @csrf_exempt
    def get(self, request):
        username = self.parse_token(request, "username")

        try:
            key = VaultKey.objects.get(username=username)
            return HttpResponse(key.toJson(), content_type="application/json", status=200)
        except ObjectDoesNotExist:
            return HttpResponse(json.dumps({"message": "no data found!"}), content_type="application/json", status=404)
    
    @csrf_exempt
    def post(self, request):
        username = self.parse_token(request, "username")
        new_key = request.POST.get("key") 
        
        try:
            key = VaultKey.objects.get(username=username)
            key.data = new_key
            key.save()
            return HttpResponse(json.dumps({"message": "Key updated!"}), content_type="application/json", status=200)

        except ObjectDoesNotExist:
            key = VaultKey(username=username, data=new_key) 
            key.save()
            return HttpResponse(json.dumps({"message": "New key created!"}), content_type="application/json", status=404)


    def parse_token(self, request, field):
        token = str(get_authorization_header(request))[1:-1].split(" ")[1]
        token_data = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return token_data[field]

@permission_classes((IsAuthenticated,))
class VaultHandler(APIView):

    @csrf_exempt
    def get(self, request):
        since = request.GET.get("since") 
        uid = request.GET.get("uid")
        username = self.parse_token(request, "username")
        
        try:
            # handle if optional uid provided
            if uid:
                print("DEBUG", uid, username)
                obj = Vault.objects.get(uid=uid, username=username)
            
                return HttpResponse(obj.toJson(), content_type="application/json", status=200)

            # handle if optional since
            resp = []
            if since:
                obj = Vault.objects.filter(atime__gt=since, username=username)
                for x in obj:
                    resp.append(x.toJson())
                return HttpResponse(resp, content_type="application/json", status=200)

            # return whole vault
            res = Vault.objects.filter(username=username).values()
            for x in res:
                resp.append(x)
                x["uid"] = str(x["uid"])
            return HttpResponse(json.dumps(resp), content_type="application/json", status=200)
        except ObjectDoesNotExist:
            return HttpResponse(json.dumps({"message": "no data found!"}), content_type="application/json", status=404)

    @csrf_exempt
    def put(self, request):
        received_json_data=json.loads(request.body)
        
        username = self.parse_token(request, "username")
        modified = 0
        created = 0
        same = 0

        for e in received_json_data:
            new = Vault(username=username,
                    type = e["type"],
                    uid = e["id"],
                    data = e["data"],
                    atime = e["atime"]
                    )

            try:
                # validate if exists
                entry = Vault.objects.get(uid=e["id"], username=username)
                
                if new == entry:
                    same += 1
                    continue

                entry.type = e["type"]
                entry.uid = e["id"]
                entry.data = e["data"]
                entry.atime = e["atime"]
                entry.save()
                modified += 1
            
            except ObjectDoesNotExist:
                # create new
                created += 1
                new.save()

        return HttpResponse(json.dumps({"message": "vault updated!", "Vault": { "created": created, "modified": modified, "same": same } }), content_type="application/json", status=200)

    def parse_token(self, request, field):
        token = str(get_authorization_header(request))[1:-1].split(" ")[1]
        token_data = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return token_data[field]
