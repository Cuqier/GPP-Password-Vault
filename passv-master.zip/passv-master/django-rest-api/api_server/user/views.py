from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from django.views.decorators.csrf import csrf_exempt
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate
from rest_framework_simplejwt.token_blacklist.models import BlacklistedToken, OutstandingToken


from django.contrib.auth.models import User
from django.http import HttpResponse
import json
import jwt
from rest_framework_simplejwt.views import TokenObtainPairView
from user.serializers import MyTokenObtainPairSerializer
from rest_framework.authentication import get_authorization_header
from api_server.settings import SECRET_KEY


from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from user.activate_tokens import account_activation_token
from vault.models import Vault, VaultKey


class PassvUsers(APIView):

    def get_permissions(self):
        permission_classes = [IsAuthenticated]
        if self.request.method == "POST":
            permission_classes = [AllowAny]
        return [permission() for permission in permission_classes]

    @csrf_exempt
    def get(self, request):
        return Response({'res': 'ok'})

    @csrf_exempt
    def post(self, request):
        
        password = request.POST.get("password")
        email = request.POST.get("username")

        if authenticate(username=email, password=password):
            return HttpResponse(json.dumps({"message": "User exists in database."}, indent=2, separators=(',', ': ')),
                                content_type="application/json", status=403)

        user = User.objects.create_user(username=email)
        user.email = email
        user.set_password(password)
        user.is_active = False
        user.save()

        activate_uid = urlsafe_base64_encode(force_bytes(user.pk))
        activate_token = account_activation_token.make_token(user)
        encoded_eml = urlsafe_base64_encode(force_bytes(email))

        message = {
                'user': email,
                'domain': 'localhost:8000', #current_site.domain,
                'uid': activate_uid,
                'token': activate_token,
                'athorization_url': f"localhost:8000/user/activate/{activate_uid}/{activate_token}/"
            }

        subject = 'Activate Your PassV Account'
        emailmsg = render_to_string('account_activation_email.html', {
            'user': email,
            'link': f'http://localhost:8888/register/index3.html?eml={encoded_eml}&uid={activate_uid}&token={activate_token}'
        })
        user.email_user(subject, emailmsg)


        return HttpResponse(json.dumps({"message": "User successfully created!", "activation": message}, indent=2,
                separators=(',', ': ')), content_type="application/json", status=200)
    
    @csrf_exempt
    def delete(self, request):
        token = str(get_authorization_header(request))[1:-1].split(" ")[1]
        token_data = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        username = token_data["username"]
        #password = request.POST.get("password")
        #print("DEBUG", password)

        user = User.objects.get(username=username)
        #if not authenticate(username=username, password=password):
        if not user: 
            return HttpResponse(json.dumps({"message": "User does not exists in database."}, indent=2, separators=(',', ': ')),
                                content_type="application/json", status=403)

        # delete user data
        Vault.objects.filter(username=username).delete()
        VaultKey.objects.get(username=username).delete()

        user = User.objects.get(username=username)
        user.delete()
        return HttpResponse(json.dumps({"message": "User successfully deleted!"}, indent=2,separators=(',', ': ')),
                                content_type="application/json", status=200)

    @csrf_exempt
    def patch(self, request):
        token = str(get_authorization_header(request))[1:-1].split(" ")[1]
        token_data = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        username = token_data["username"]
        password = request.POST.get("password")
        
        user = User.objects.get(username=username)

        #if not authenticate(username=username, password=password):
        if not user: 
            return HttpResponse(json.dumps({"message": "User does not exists in database."}, indent=2, separators=(',', ': ')),
                                content_type="application/json", status=403)
        
        user = User.objects.get(username=username)
        user.set_password(password)
        user.save()

        return HttpResponse(json.dumps({"message": "Password successfully changed!"}, indent=2,separators=(',', ': ')),
                                content_type="application/json", status=200)


# user activation
@permission_classes((AllowAny,))
class UserActivation(APIView):

    @csrf_exempt
    def get(self, request, uidb64, token):
        try:
            uid = force_text(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=uid)
        except(TypeError, ValueError, OverflowError, User.DoesNotExist):
            user = None

        if user is not None and account_activation_token.check_token(user, token):
            user.is_active = True
            user.save()
            return HttpResponse(json.dumps({"message": "Thank you for your confirmation. Now you can login your account."},
                indent=2, separators=(',', ': ')), content_type="application/json", status=200) 
        else:
            return HttpResponse(json.dumps({"message": "Activation link is invalid!"},
                indent=2,separators=(',', ': ')), content_type="application/json", status=400) 



# add username field to JWT
class MyObtainTokenPairView(TokenObtainPairView):
    permission_classes = (AllowAny,)
    serializer_class = MyTokenObtainPairSerializer


@permission_classes((IsAuthenticated,))
class LogoutAllView(APIView):

    @csrf_exempt
    def post(self, request):
        tokens = OutstandingToken.objects.filter(user_id=request.user.id)
        for token in tokens:
            t, _ = BlacklistedToken.objects.get_or_create(token=token)
        return HttpResponse(json.dumps({"message": "User loggedout!"}, indent=2,separators=(',', ': ')),
                                content_type="application/json", status=205)
