#!/bin/sh

cd "$(dirname "$(realpath "$0")")"

basedir="$(pwd)"
addr='localhost:8000'

cp api_server/api_server/settings.py api_server/api_server/settings.py.old
cp test/settings.py.testenv api_server/api_server/settings.py

python3 -mvenv --system-site-packages server-venv
. server-venv/bin/activate
pip3 install -r requirements.txt

cleanup() {
	echo "cleaning up"
	cd "$basedir"
	mv api_server/api_server/settings.py.old api_server/api_server/settings.py
	rm -fr server-venv
}
trap 'cleanup' EXIT INT

cd api_server
	rm -f db.sqlite3
	python3 manage.py makemigrations vault
	python3 manage.py makemigrations user
	python3 manage.py migrate
	python3 manage.py runserver >/tmp/serverout 2>&1 &
	srvpid="$!"
	sleep 5
cd -

passed=0
failed=0

printf '\n\n\n\033[1mServer preparation complete.  Running tests...\033[m\n'

for f in test/*; do
	if [ -x "$f" ]; then
		printf "Running '%s'...    " "$f" >&2
		if "$f" > /tmp/stdout; then
			passed="$((passed+1))"
		else
			failed="$((failed+1))"
			cat /tmp/stdout
		fi
	fi
done

printf '

\033[1mSummary:
    \033[32m%d\033[39m test(s) passed
    \033[31m%d\033[39m test(s) failed
\033[m\n' "$passed" "$failed" >&2

kill "$srvpid"
sleep 3

[ "$failed" -eq 0 ]
