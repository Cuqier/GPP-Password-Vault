#!/bin/sh
cd "$(dirname "$(realpath "$0")")"
exec python3 -mhttp.server 8888
