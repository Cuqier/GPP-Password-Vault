apiAddress = "localhost:8000"

function submitForm() {
    async function makeKeys() {
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;
        console.log(username, password);
        await initKeys(username, password);

        var resp = await fetch(`http://${apiAddress}/user/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8' },
            body: new URLSearchParams({
                username,
                password: b64enc(loginHash)
            })
        });
        //var data = await resp.json();
        //console.log(data);
    }

    makeKeys().then(function() {
        console.log("created credentials");
        window.location = "index2.html";
    });
}

function submitForm2() {
    console.log("Hello, world!");
    async function doStuff() {
        var urlString = window.location.href;
        var paramString = urlString.split('?')[1];
        var queryString = new URLSearchParams(paramString);
        var eml = atob(queryString.get("eml"));
        var uid = queryString.get("uid");
        var token = queryString.get("token");
        var pass = document.getElementById("password").value;
        console.log(eml, uid, token);

        await fetch(`http://${apiAddress}/user/activate/${uid}/${token}/`);

        theEmail = eml;

        await initKeys(eml, pass);
        await initSync();

        keyForDB = await aesGenKey();
        plainKey = await aesExportKey(keyForDB);
        cryptKey = await aesEncrypt(plainKey, masterKey);
        await syncSetKey(b64enc(cryptKey));
    }

    doStuff().then(function() {
        console.log("created vault key");
        window.location = "index4.html";
    });
}
